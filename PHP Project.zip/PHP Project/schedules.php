<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="code/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="style.css">
	<link rel="stylesheet" type="text/css" href="animation.css">
	<script type="text/javascript" src="code/bootstrap.min.js"></script>
	<script type="text/javascript" src="code/jquery.min.js"></script>
	<script type="text/javascript" src="code/popper.min.js"></script>
	<title>Alpha Fitness</title>
</head>
<body data-spy="scroll" data-target=".navbar" data-offset="50">
	
	<nav class="navbar navbar-expand-sm navbar-dark fixed-top" id="navbar">
  		<ul class="navbar-nav">
    		<li class="nav-item">
     			<p id="name" href="index.html">Alpha Fitness</p>
    		</li>
    		<li class="nav-item">
    		  <a class="nav-link btn nav-button text-light" href="home.php"><b>HOME</b></a>
    		</li>
    		<li class="nav-item">
    		  <a class="nav-link btn nav-button text-light" href="classes.php"><b>CLASSES</b></a>
    		</li>
    		<li class="nav-item">
    		  <a class="nav-link btn nav-button text-light" href="trainers.php"><b>TRAINERS</b></a>
    		</li>
    		<li class="nav-item">
    		  <a class="nav-link btn nav-button text-light" id="btn" href="schedules.php"><b>SCHEDULES</b></a>
    		</li>
    		<li class="nav-item">
    		  <a class="nav-link btn nav-button text-light" href="contact.php"><b>CONTACT US</b></a>
    		</li>
    		<li class="nav-item">
    		  <a class="nav-link btn nav-button text-light" href="marketplace.php"><b>MARKETPLACE</b></a>
    		</li>
  		</ul> 
	</nav>

	<main>
	<section>
	<div class="jumbotron text-center classes">
		<h1 class="class-heading bounce-top">schedules</h1>
	</div>

	<center>
	<div class="container">
		<table border="1"  class="table text-center text-light">
			<tr class="table-row1">
				<td id="day-col">Monday</td>
				<td id="day-col">Tuesday</td>
				<td id="day-col">Wednesday</td>
				<td id="day-col">Thursday</td>
				<td id="day-col">Friday</td>
				<td id="day-col">Saturday</td>
			</tr>
			<tr>
				<td id="activity-col">Boxing<br><small class="text-muted">6:00 AM - 9:00 AM</small></td>
				<td id="activity-col">Aerobic<br><small class="text-muted">6:00 AM - 9:00 AM</small></td>
				<td id="activity-col">Yoga<br><small class="text-muted">6:00 AM - 9:00 AM</small></td>
				<td id="activity-col">Aerobic<br><small class="text-muted">6:00 AM - 9:00 AM</small></td>
				<td id="activity-col">Boxing<br><small class="text-muted">6:00 AM - 9:00 AM</small></td>
				<td id="activity-col">Yoga<br><small class="text-muted">6:00 AM - 9:00 AM</small></td>
			</tr>
			<tr>
				<td id="activity-col">Body Building<br><small class="text-muted">7:00 AM - 10:00 AM</small></td>
				<td id="activity-col">Weight-Lifting<br><small class="text-muted">8:00 AM - 10:00 AM</small></td>
				<td id="activity-col"></td>
				<td id="activity-col">Body Building<br><small class="text-muted">7:00 AM - 10:00 AM</small></td>
				<td id="activity-col">Weight-Lifting<br><small class="text-muted">8:00 AM - 10:00 AM</small></td>
				<td id="activity-col"></td>
			</tr>
			<tr>
				<td id="activity-col">Aerobic<br><small class="text-muted">10:00 AM - 12:00 AM</small></td>
				<td id="activity-col">Body Building<br><small class="text-muted">9:00 AM - 12:00 AM</small></td>
				<td id="activity-col">Body Building<br><small class="text-muted">9:00 AM - 12:00 AM</small></td>
				<td id="activity-col"></td>
				<td id="activity-col"></td>
				<td id="activity-col">Boxing<br><small class="text-muted">10:00 AM - 12:00 AM</small></td>
			</tr>
			<tr>
				<td id="activity-col"></td>
				<td id="activity-col">Yoga<br><small class="text-muted">2:00 PM - 4:00 PM</small></td>
				<td id="activity-col">Boxing<br><small class="text-muted">2:00 PM - 4:00 PM</small></td>
				<td id="activity-col">Weight-Lifting<br><small class="text-muted">3:00 PM - 4:00 PM</small></td>
				<td id="activity-col">Body Building<br><small class="text-muted">2:00 PM - 4:00 PM</small></td>
				<td id="activity-col">Aerobic<br><small class="text-muted">2:00 PM - 4:00 PM</small></td>
			</tr>
			<tr>
				<td id="activity-col">Weight-Lifting<br><small class="text-muted">4:00 PM - 6:00 PM</small></td>
				<td id="activity-col"></td>
				<td id="activity-col">Aerobic<br><small class="text-muted">5:00 PM - 6:00 PM</small></td>
				<td id="activity-col">Yoga<br><small class="text-muted">4:00 PM - 6:00 PM</small></td>
				<td id="activity-col">Karate<br><small class="text-muted">4:00 PM - 6:00 PM</small></td>
				<td id="activity-col">Karate<br><small class="text-muted">4:00 PM - 6:00 PM</small></td>
			</tr>
			<tr>
				<td id="activity-col">Yoga<br><small class="text-muted">6:00 PM - 8:00 PM</small></td>
				<td id="activity-col">Boxing<br><small class="text-muted">6:00 PM - 8:00 PM</small></td>
				<td id="activity-col">Weight-Lifting<br><small class="text-muted">6:00 PM - 8:00 PM</small></td>
				<td id="activity-col">Boxing<br><small class="text-muted">6:00 PM - 8:00 PM</small></td>
				<td id="activity-col">Aerobic<br><small class="text-muted">6:00 PM - 8:00 PM</small></td>
				<td id="activity-col">Yoga<br><small class="text-muted">6:00 PM - 8:00 PM</small></td>
			</tr>
		</table>
	</div>
	</center>
	<br><br>
	</section>
	</main>

	<footer>
		<br>
		<div class="container text-center">
			<div class="text-light">
				Copyright &copy; Alpha Fitness.Co
			</div>
		</div>
		<br>
	</footer>