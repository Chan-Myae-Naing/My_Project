<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="code/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="style.css">
	<link rel="stylesheet" type="text/css" href="animation.css">
	<script type="text/javascript" src="code/bootstrap.min.js"></script>
	<script type="text/javascript" src="code/jquery.min.js"></script>
	<script type="text/javascript" src="code/popper.min.js"></script>
	<title>Alpha Fitness</title>
</head>
<body data-spy="scroll" data-target=".navbar" data-offset="50">
	
	<nav class="navbar navbar-expand-sm navbar-dark fixed-top" id="navbar">
  		<ul class="navbar-nav">
    		<li class="nav-item">
     			<p id="name" href="index.html">Alpha Fitness</p>
    		</li>
    		<li class="nav-item">
    		  <a class="nav-link btn nav-button text-light" href="home.php"><b>HOME</b></a>
    		</li>
    		<li class="nav-item">
    		  <a class="nav-link btn nav-button text-light" href="classes.php"><b>CLASSES</b></a>
    		</li>
    		<li class="nav-item">
    		  <a class="nav-link btn nav-button text-light" id="btn" href="trainers.php"><b>TRAINERS</b></a>
    		</li>
    		<li class="nav-item">
    		  <a class="nav-link btn nav-button text-light" href="schedules.php"><b>SCHEDULES</b></a>
    		</li>
    		<li class="nav-item">
    		  <a class="nav-link btn nav-button text-light" href="contact.php"><b>CONTACT US</b></a>
    		</li>
    		<li class="nav-item">
    		  <a class="nav-link btn nav-button text-light" href="marketplace.php"><b>MARKETPLACE</b></a>
    		</li>
  		</ul> 
	</nav>

	<manin>
	<section>
	<div class="jumbotron text-center classes">
		<h1 class="class-heading bounce-top">trainers</h1>
	</div>
	
	<div class="container">
		<div class="card mb-3 classes slide-in-left-1" style="max-width: 540px;">
  			<div class="row g-0">
    			<div class="col-md-4">
      				<img src="img/mike-tyson.jpg" class="img-fluid rounded-start" alt="Mike Tyson">
    			</div>
    			<div class="col-md-8">
      				<div class="card-body">
        				<h4 class="card-title" style="color: red; text-transform: uppercase;"><b>Boxing</b></h4>
        				<br>
        				<h5 class="card-text text-light">Mike Tyson</h5>
        				<p class="card-text"><small class="text-muted">A professional boxer</small></p>
      				</div>
    			</div>
  			</div><!--row-->
		</div><!--card-->
		<div class="row">
			<div class="col"></div>
			<div class="col"></div>
			<div class="card mb-3 classes slide-in-right-1" style="max-width: 540px;">
  			<div class="row g-0">
    			<div class="col-md-4">
      				<img src="img/anna.jpg" class="img-fluid rounded-start" alt="Anna">
    			</div>
    			<div class="col-md-8">
      				<div class="card-body">
        				<h4 class="card-title" style="color: red; text-transform: uppercase;"><b>Yoga</b></h4>
        				<br>
        				<h5 class="card-text text-light">Anna</h5>
        				<p class="card-text"><small class="text-muted">Yoga Instructor</small></p>
      				</div>
    			</div>
  			</div><!--row-->
		</div><!--card-->
		</div>
		<div class="card mb-3 classes slide-in-left-2" style="max-width: 540px;">
  			<div class="row g-0">
    			<div class="col-md-4">
      				<img src="img/bella.webp" class="img-fluid rounded-start" alt="Bella">
    			</div>
    			<div class="col-md-8">
      				<div class="card-body">
        				<h4 class="card-title" style="color: red; text-transform: uppercase;"><b>Aerobic</b></h4>
        				<br>
        				<h5 class="card-text text-light">Bella</h5>
        				<p class="card-text"><small class="text-muted">Aerobic Instructor</small></p>
      				</div>
    			</div>
  			</div><!--row-->
		</div><!--card-->
		<div class="row">
			<div class="col"></div>
			<div class="col"></div>
			<div class="card mb-3 classes slide-in-right-2" style="max-width: 540px;">
  			<div class="row g-0">
    			<div class="col-md-4">
      				<img src="img/cbum.jfif" class="img-fluid rounded-start" alt="Chris Bumstead">
    			</div>
    			<div class="col-md-8">
      				<div class="card-body">
        				<h4 class="card-title" style="color: red; text-transform: uppercase;"><b>Body Bulilding</b></h4>
        				<br>
        				<h5 class="card-text text-light">Chris Bumstead</h5>
        				<p class="card-text"><small class="text-muted">Mr.Olympia and Gym Trainer</small></p>
      				</div>
    			</div>
  			</div><!--row-->
		</div><!--card-->
		</div>
		<div class="card mb-3 classes slide-in-left-3" style="max-width: 540px;">
  			<div class="row g-0">
    			<div class="col-md-4">
      				<img src="img/eddiehall.jpg" class="img-fluid rounded-start" alt="Eddie Hall">
    			</div>
    			<div class="col-md-8">
      				<div class="card-body">
        				<h4 class="card-title" style="color: red; text-transform: uppercase;"><b>Weight-Lifting</b></h4>
        				<br>
        				<h5 class="card-text text-light">Eddie Hall</h5>
        				<p class="card-text"><small class="text-muted">Weight-Lifting instructor</small></p>
      				</div>
    			</div>
  			</div><!--row-->
		</div><!--card-->
		<div class="row">
			<div class="col"></div>
			<div class="col"></div>
			<div class="card mb-3 classes slide-in-right-3" style="max-width: 540px;">
  			<div class="row g-0">
    			<div class="col-md-4">
      				<img src="img/johndoe.jpg" class="img-fluid rounded-start" alt="John Doe">
    			</div>
    			<div class="col-md-8">
      				<div class="card-body">
        				<h4 class="card-title" style="color: red; text-transform: uppercase;"><b>Karate</b></h4>
        				<br>
        				<h5 class="card-text text-light">John Doe</h5>
        				<p class="card-text"><small class="text-muted">Karate instructor</small></p>
      				</div>
    			</div>
  			</div><!--row-->
		</div><!--card-->
		</div>
	</div><!--/container-->
	</section>
	</main>

	<footer>
		<br>
		<div class="container text-center">
			<div class="text-light">
				Copyright &copy; Alpha Fitness.Co
			</div>
		</div>
		<br>
	</footer>