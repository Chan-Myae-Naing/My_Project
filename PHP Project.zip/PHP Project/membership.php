<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="code/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="style.css">
	<link rel="stylesheet" type="text/css" href="animation.css">
	<script type="text/javascript" src="code/bootstrap.min.js"></script>
	<script type="text/javascript" src="code/jquery.min.js"></script>
	<script type="text/javascript" src="code/popper.min.js"></script>
	<title>Alpha Fitness</title>
</head>
<body data-spy="scroll" data-target=".navbar" data-offset="50">

	<nav class="navbar navbar-expand-sm navbar-dark fixed-top" id="navbar">
  		<ul class="navbar-nav">
    		<li class="nav-item">
     			<p id="name" href="index.html">Alpha Fitness</p>
    		</li>
    		<li class="nav-item">
    		  <a class="nav-link btn nav-button text-light" href="home.php"><b>HOME</b></a>
    		</li>
    		<li class="nav-item">
    		  <a class="nav-link btn nav-button text-light" href="classes.php"><b>CLASSES</b></a>
    		</li>
    		<li class="nav-item">
    		  <a class="nav-link btn nav-button text-light" href="trainers.php"><b>TRAINERS</b></a>
    		</li>
    		<li class="nav-item">
    		  <a class="nav-link btn nav-button text-light" href="schedules.php"><b>SCHEDULES</b></a>
    		</li>
    		<li class="nav-item">
    		  <a class="nav-link btn nav-button text-light" href="contact.php"><b>CONTACT US</b></a>
    		</li>
    		<li class="nav-item">
    		  <a class="nav-link btn nav-button text-light" href="marketplace.php"><b>MARKETPLACE</b></a>
    		</li>
  		</ul> 
	</nav>

	<main>
	<div class="jumbotron classes text-center bounce-top">
		<h1 class="class-heading">Membership-Registration</h1>
		<p class="text-light">Complete the form below to sign up for our membership service.</p>
	</div>
	<br>

	<div class="container">
		<form method="post">

			<div class="row">
				<div class="col-sm-2"></div>
				<div class="col-sm-2">
					<div class="card" style="width:700px; margin: 20px;">
						<div class="card-header membership-heading text-center">
							Membership Form
						</div>
						<br>

						<?php

							error_reporting(1);
							include("connection.php");
							if($_POST["sub"]){
								$fn = $_POST["fn"];
								$ln = $_POST["ln"];
								$email = $_POST["email"];
								$mob = $_POST["mob"];
								$addr = $_POST["addr"];
								$bm = $_POST["bm"];
								$bd = $_POST["bd"];
								$by = $_POST["by"];
								$pck = $_POST["package"];
								$pay = $_POST["pay"];
								$kf = $_POST["kf"];
								
								if(mysql_query("insert into membership(FirstName,LastName,Email,Mobile,Address,BirthMonth,BirthDay,BirthYear,Package,Payment,Knownfrom) values('$fn','$ln','$email','$mob','$addr','$bm','$bd','$by','$pck','$pay','$kf')")){
									echo "<div class='card-header bg-success text-center text-light'>Regristration Completed!&nbsp;<a class='bg-info text-light' href='home.php'>Go Back</a></div>";
								}
								else{
									die(mysql_error());
								}
							}

						?>
				
					<div class="card-body">
						<h5 class="card-title">Name</h5>
						<input type="text" name="fn" required placeholder="First Name" size="27">
						<input type="text" name="ln" placeholder="Last Name(optional)" size="27">
						<br><br>
					
						<h5 class="card-title">Email</h5>
						<input type="email" name="email" required placeholder="@gmail.com" required size="60">
						<br><br>
					
						<h5 class="card-title">Mobile</h5>
						<input type="text" name="mob" required size="27">
						<br><br>

						<h5 class="card-title">Address</h5>
						<input type="text" name="addr" required size="60">
						<br><br>

						<h5 class="card-title">Date of Birth</h5>
						<select required name="bm">
							<option>January</option>
							<option>February</option>
							<option>March</option>
							<option>April</option>
							<option>May</option>
							<option>June</option>
							<option>July</option>
							<option>August</option>
							<option>September</option>
							<option>October</option>
							<option>November</option>
							<option>December</option>
						</select>
						<select required name="bd">
							<option>1</option>
							<option>2</option>
							<option>3</option>
							<option>4</option>
							<option>5</option>
							<option>6</option>
							<option>7</option>
							<option>8</option>
							<option>9</option>
							<option>10</option>
							<option>11</option>
							<option>12</option>
							<option>13</option>
							<option>14</option>
							<option>15</option>
							<option>16</option>
							<option>17</option>
							<option>18</option>
							<option>19</option>
							<option>20</option>
							<option>21</option>
							<option>22</option>
							<option>23</option>
							<option>24</option>
							<option>25</option>
							<option>26</option>
							<option>27</option>
							<option>28</option>
							<option>29</option>
							<option>30</option>
							<option>31</option>
						</select>
						<select required name="by">
							<option>2022</option>
							<option>2021</option>
							<option>2020</option>
							<option>2019</option>
							<option>2018</option>
							<option>2017</option>
							<option>2016</option>
							<option>2015</option>
							<option>2014</option>
							<option>2013</option>
							<option>2012</option>
							<option>2011</option>
							<option>2010</option>
							<option>2009</option>
							<option>2008</option>
							<option>2007</option>
							<option>2006</option>
							<option>2005</option>
							<option>2004</option>
							<option>2003</option>
							<option>2002</option>
							<option>2001</option>
							<option>2000</option>
							<option>1999</option>
							<option>1998</option>
							<option>1997</option>
							<option>1996</option>
							<option>1995</option>
							<option>1994</option>
							<option>1993</option>
							<option>1992</option>
							<option>1991</option>
							<option>1990</option>
							<option>1989</option>
							<option>1988</option>
							<option>1987</option>
							<option>1986</option>
							<option>1985</option>
							<option>1984</option>
							<option>1983</option>
							<option>1982</option>
							<option>1981</option>
							<option>1980</option>
						</select>
						<br><br>

						<h5 class="card-title">Payment Method</h5>
						<select required name="pay">
							<option>Kpay</option>
							<option>Wavepay</option>
							<option>Cash</option>
						</select>
						<br><br>

						<h5 class="card-title">Package</h5>
						<select name="package" required>
							<option name="pck1">1 months - ks 30,000</option>
							<option name="pck2">3 months - ks 80,000</option>
							<option name="pck3">6 months - ks 160,000</option>
							<option name="pck4">9 months - ks 240,000</option>
							<option name="pck5">1 year   - ks 320,000</option>
						</select>
						<br><br>

						<h5 class="card-title">How did you know us?</h5>
						<select name="kf">
							<option>Facebook</option>
							<option>Google</option>
							<option>From a friend</option>
							<option>Other</option>
						</select>
						<br><br>

						<h5 class="card-title">Rules for all members</h5>
						<ol>
							<li>Must bring a towel with you.</li>
							<li>Can't take any visitors.</li>
							<li>Don't be a gym creep.</li>
						</ol>
						<input type="checkbox" required> <b>I have read, understood and accepted the rules.</b>
						<br><br>

						<div class="card-footer text-center">
							<div class="row">
								<div class="col">
									<input type="reset" value="Cancel" class="btn btn-secondary d-grid gap-2 col-6 mx-auto">
								</div>
								<div class="col">
									<input type="submit" value="Submit" name="sub" class="btn btn-danger d-grid gap-2 col-6 mx-auto" id="btn">
								</div>
							</div>
						</div>
					</div><!--card body-->
					</div><!--card-->
				</div><!--col-->
			</div><!--row-->

		</form>
	</div>
	</main>
	<br><br>

	<footer>
		<br>
		<div class="container text-center">
			<div class="text-light">
				Copyright &copy; Alpha Fitness.Co
			</div>
		</div>
		<br>
	</footer>

</body>
</html>