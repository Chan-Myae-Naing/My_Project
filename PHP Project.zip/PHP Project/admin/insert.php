<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="code/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="admin_style.css">
    <link rel="stylesheet" type="text/css" href="animation.css">
	<script type="text/javascript" src="code/bootstrap.min.js"></script>
	<script type="text/javascript" src="code/jquery.min.js"></script>
	<script type="text/javascript" src="code/popper.min.js"></script>
	<title>Alpha Fitness</title>
</head>
<body data-spy="scroll" data-target=".navbar" data-offset="50">
	
<nav class="navbar navbar-expand-sm navbar-dark fixed-top" id="navbar">
  		<ul class="navbar-nav">
    		<li class="nav-item">
     			<p id="name">Admin Dashboard</p>
    		</li>
    		<li class="nav-item">
    		  <a class="nav-link btn nav-button text-light" id="btn" href="insert.php"><b>INSERT</b></a>
    		</li>
    		<li class="nav-item">
    		  <a class="nav-link btn nav-button text-light" href="product.php"><b>PRODUCT</b></a>
    		</li>
    		<li class="nav-item">
    		  <a class="nav-link btn nav-button text-light" href="orders.php"><b>ORDERS</b></a>
    		</li>
			<li class="nav-item">
    		  <a class="nav-link btn nav-button text-light" href="membership.php"><b>MEMBERS</b></a>
    		</li>
    		<li class="nav-item">
    		  <a class="nav-link btn nav-button text-light" href="feedback.php"><b>FEEDBACK</b></a>
    		</li>
    		<li class="nav-item">
    		  <a class="nav-link btn nav-button text-light" href="logout.php"><b>LOG OUT</b></a>
    		</li>
  		</ul> 
	</nav><br><br>

    <main>
        <div class="container" id="bg-black">
            <h1 class="bounce-top text-center" id="class-heading">Insert Items</h1>
			<br><br>

        <?php

        error_reporting(1);
        include("connection.php");
        if($_POST["sub"]){
            if($_POST["categorie"] == "Dumbbells"){
                $img = $_POST["img"];
                $prod_name = $_POST["prod_name"];
                $prod_info = $_POST["prod_info"];
                $price = $_POST["price"];
                if(mysql_query("insert into dumbbells(img, prod_name, prod_info, price) values('$img', '$prod_name', '$prod_info', '$price')")){
                    echo "<center><p style='font-size:30px; font-weight:bold;' class='text-success'>Product Successfully Added!</p></center><br><br>";
                }
                else{
                    die(mysql_error());
                }
            }
            elseif($_POST["categorie"] == "Barbells-and-Weights"){
                $img = $_POST["img"];
                $prod_name = $_POST["prod_name"];
                $prod_info = $_POST["prod_info"];
                $price = $_POST["price"];
                if(mysql_query("insert into barbells(img, prod_name, prod_info, price) values('$img', '$prod_name', '$prod_info', '$price')")){
                    echo "<center><p style='font-size:30px; font-weight:bold;' class='text-success'>Product Successfully Added!</p></center><br><br>";
                }
                else{
                    die(mysql_error());
                }
            }
            elseif($_POST["categorie"] == "Supplements"){
                $img = $_POST["img"];
                $prod_name = $_POST["prod_name"];
                $prod_info = $_POST["prod_info"];
                $price = $_POST["price"];
                if(mysql_query("insert into supplements(img, prod_name, prod_info, price) values('$img', '$prod_name', '$prod_info', '$price')")){
                    echo "<center><p style='font-size:30px; font-weight:bold;' class='text-success'>Product Successfully Added!</p></center><br><br>";
                }
                else{
                    die(mysql_error());
                }
            }
            elseif($_POST["categorie"] == "Machines"){
                $img = $_POST["img"];
                $prod_name = $_POST["prod_name"];
                $prod_info = $_POST["prod_info"];
                $price = $_POST["price"];
                if(mysql_query("insert into machines(img, prod_name, prod_info, price) values('$img', '$prod_name', '$prod_info', '$price')")){
                    echo "<center><p style='font-size:30px; font-weight:bold;' class='text-success'>Product Successfully Added!</p></center><br><br>";
                }
                else{
                    die(mysql_error());
                }
            }
        }

        ?>
			
			<div class="text-light" style="margin-left:20%">
            <form method="post">
				<div class="row">
					<div class="col">
						Choose a categorie
					</div>
					<div class="col">
						<select required name="categorie">
							<option name="db">Dumbbells</option>
							<option name="bb">Barbells-and-Weights</option>
							<option name="sup">Supplements</option>
							<option name="mac">Machines</option>
						</select>
					</div>
				</div>
				<br>
				<div class="row">
					<div class="col">
						Pick an image
					</div>
					<div class="col">
						<input required name="img" type="file">
					</div>
				</div>
				<br>
				<div class="row">
					<div class="col">
						Product Name
					</div>
					<div class="col">
						<input required name="prod_name" type="text">
					</div>
				</div>
				<br>
				<div class="row">
					<div class="col">
						Description
					</div>
					<div class="col">
						<input required name="prod_info" type="text">
					</div>
				</div>
				<br>
				<div class="row">
					<div class="col">
						Price
					</div>
					<div class="col">
						<input required name="price" type="number" placeholder="Ks">
					</div>
				</div>
				<br><br>
				<div class="row" align="center">
					<div class="col">
						<input type="reset" value="Cancel" class="btn btn-secondary">
					</div>
					<div class="col" style="margin-right:35%;">
						<input type="submit" name="sub" value="Submit" name="sub" class="btn btn-danger" id="btn">
					</div>
				</div>
            </form>
			</div>
        </div>
       
    </main><br><br>

    <footer>
		<br>
		<div class="container text-center">
			<div class="text-light">
				Copyright &copy; Alpha Fitness.Co
			</div>
		</div>
		<br>
	</footer>

</body>
</html>