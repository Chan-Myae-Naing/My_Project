<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="code/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="admin_style.css">
	<link rel="stylesheet" type="text/css" href="animation.css">
	<script type="text/javascript" src="code/bootstrap.min.js"></script>
	<script type="text/javascript" src="code/jquery.min.js"></script>
	<script type="text/javascript" src="code/popper.min.js"></script>
	<title>Alpha Fitness</title>
</head>
<body data-spy="scroll" data-target=".navbar" data-offset="50">
	
<nav class="navbar navbar-expand-sm navbar-dark fixed-top" id="navbar">
  		<ul class="navbar-nav">
    		<li class="nav-item">
     			<p id="name">Admin Dashboard</p>
    		</li>
    		<li class="nav-item">
    		  <a class="nav-link btn nav-button text-light" href="insert.php"><b>INSERT</b></a>
    		</li>
    		<li class="nav-item">
    		  <a class="nav-link btn nav-button text-light" id="btn" href="product.php"><b>PRODUCT</b></a>
    		</li>
    		<li class="nav-item">
    		  <a class="nav-link btn nav-button text-light" href="orders.php"><b>ORDERS</b></a>
    		</li>
			<li class="nav-item">
    		  <a class="nav-link btn nav-button text-light" href="membership.php"><b>MEMBERS</b></a>
    		</li>
    		<li class="nav-item">
    		  <a class="nav-link btn nav-button text-light" href="feedback.php"><b>FEEDBACK</b></a>
    		</li>
    		<li class="nav-item">
    		  <a class="nav-link btn nav-button text-light" href="logout.php"><b>LOG OUT</b></a>
    		</li>
  		</ul> 
	</nav>

	<main>
		<section>
		<div class="jumbotron" id="bg-black">
            <h1 class="bounce-top text-center" id="class-heading">Barbells and Weights</h1>
        </div>
		</section>
		<section>
			<div class="container">

			<?php
				
				error_reporting(1);
				include("connection.php");
				$sel = mysql_query("select * from barbells");
				echo "<div class='row'>";

				$n = 1;
				while($arr = mysql_fetch_array($sel)){
					$i = $arr["img"];
					if($n == 1){
						echo "<div class='row'>";
					}
					echo "
					<div class='card-group'>
					<div class='card' style='width: 18rem;'>
					<img src='img/barbells/$i' height='300' width='200' class='card-img-top' alt='$i'>
					<div class='card-body'>
					<h5 class='card-title'>".$arr['prod_name']."</h5>
					<p class='card-text'>".$arr['prod_info']." <br><br> <b>Price : Ks ".$arr['price']."</b></p>
					</div>
					</div>&nbsp;
					</div>";
					$n++;
				}
				echo "</div>";
			
			?>

			</div><!--/container-->
		</section>
	</main><br><br>

	<footer>
		<br>
		<div class="container text-center">
			<div class="text-light">
				Copyright &copy; Alpha Fitness.Co
			</div>
		</div>
		<br>
	</footer>