<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="code/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="admin_style.css">
	<link rel="stylesheet" type="text/css" href="animation.css">
	<script type="text/javascript" src="code/bootstrap.min.js"></script>
	<script type="text/javascript" src="code/jquery.min.js"></script>
	<script type="text/javascript" src="code/popper.min.js"></script>
	<title>Alpha Fitness</title>
</head>

<body data-spy="scroll" data-target=".navbar" data-offset="50">
	<main>
		<div class="container">
			<center>
			<div class="card" style="width: 18rem; margin: 13%;">
				<form method="post">
					<h1 class="card-header" id="login-header">Admin Login</h1><br>
					<input type="text" name="name" placeholder="Name" size="30" required><br><br>
					<input type="password" name="pass" placeholder="Password" size="30" required>

					<?php

					session_start();
					error_reporting(1);
					include("connection.php");
					if($_POST["sub"]){
						$d = mysql_query("select * from user where name='{$_POST['name']}' ");
						$row = mysql_fetch_object($d);
						$fname = $row->name;
						$fpass = $row->password;
						if($fname == $_POST["name"] && $fpass == $_POST["pass"]){
							$_SESSION["sid"] = $_POST["name"];
							header("location:insert.php");
						}
						else{
							echo "<br><br><p style='color:red; font-weight:bold;'>Invalid Name or Password!</p>";
						}
					}

					?>
					<br><br>
					<div class="card-footer text-center">
						<div class="row">
							<div class="col">
								<input type="reset" value="Cancel" class="btn btn-secondary">
							</div>
							<div class="col">
								<input type="submit" value="Submit" name="sub" class="btn btn-danger" id="btn">
							</div>
						</div>
					</div>
				</form>
			</div>
			</center>
		</div>
	</main>


</body>
</html>