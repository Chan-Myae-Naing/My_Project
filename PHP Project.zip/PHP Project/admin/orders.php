<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="code/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="admin_style.css">
    <link rel="stylesheet" type="text/css" href="animation.css">
	<script type="text/javascript" src="code/bootstrap.min.js"></script>
	<script type="text/javascript" src="code/jquery.min.js"></script>
	<script type="text/javascript" src="code/popper.min.js"></script>
	<title>Alpha Fitness</title>
</head>
<body data-spy="scroll" data-target=".navbar" data-offset="50">
	
	<nav class="navbar navbar-expand-sm navbar-dark fixed-top" id="navbar">
  		<ul class="navbar-nav">
    		<li class="nav-item">
     			<p id="name">Admin Dashboard</p>
    		</li>
    		<li class="nav-item">
    		  <a class="nav-link btn nav-button text-light" href="insert.php"><b>INSERT</b></a>
    		</li>
    		<li class="nav-item">
    		  <a class="nav-link btn nav-button text-light" href="product.php"><b>PRODUCT</b></a>
    		</li>
    		<li class="nav-item">
    		  <a class="nav-link btn nav-button text-light" id="btn" href="orders.php"><b>ORDERS</b></a>
    		</li>
			<li class="nav-item">
    		  <a class="nav-link btn nav-button text-light" href="membership.php"><b>MEMBERS</b></a>
    		</li>
    		<li class="nav-item">
    		  <a class="nav-link btn nav-button text-light" href="feedback.php"><b>FEEDBACK</b></a>
    		</li>
    		<li class="nav-item">
    		  <a class="nav-link btn nav-button text-light" href="logout.php"><b>LOG OUT</b></a>
    		</li>
  		</ul> 
	</nav>

    <main>
        <div class="jumbotron" id="bg-black">
            <h1 class="bounce-top text-center" id="class-heading">View Orders</h1>
        </div>
        <div align="center">
            <table class="tbl text-light text-center" border="1">
                <tr id="row" class="table-row1">
                    <td>ID</td>
                    <td>Product Name</td>
                    <td>Price</td>
                    <td>Name</td>
					<td>Phone</td>
					<td>Address</td>
					<td>Order code</td>
                </tr>
                <?php
					error_reporting(1);
					include("connection.php");
					    $sel=mysql_query("select * from orders");
						while($row=mysql_fetch_array($sel)){		
							$id=$row['ord_id'];					
							$prod_name=$row['prod_name'];
							$price=$row['price'];
							$name=$row['name'];
							$phone=$row['phone'];
							$addr=$row['addr'];
							$ord_no=$row['ord_no'];
				?>
                <tr id="row">
                    <td><?php echo $id; ?></td>
                    <td><?php echo $prod_name; ?></td>
                    <td><?php echo $price."&nbsp; Ks"; ?></td>
                    <td><?php echo $name; ?></td>
					<td><?php echo $phone; ?></td>
                    <td><?php echo $addr; ?></td>
                    <td><?php echo $ord_no; ?></td>
                </tr>
                <?php
                        }
                ?>
                
            </table>
        </div>
    </main>
    <br><br>

    <footer>
		<br>
		<div class="container text-center">
			<div class="text-light">
				Copyright &copy; Alpha Fitness.Co
			</div>
		</div>
		<br>
	</footer>

</body>
</html>