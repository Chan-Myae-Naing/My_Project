<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="code/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="admin_style.css">
    <link rel="stylesheet" type="text/css" href="animation.css">
	<script type="text/javascript" src="code/bootstrap.min.js"></script>
	<script type="text/javascript" src="code/jquery.min.js"></script>
	<script type="text/javascript" src="code/popper.min.js"></script>
	<title>Alpha Fitness</title>
</head>
<body data-spy="scroll" data-target=".navbar" data-offset="50">
	
<nav class="navbar navbar-expand-sm navbar-dark fixed-top" id="navbar">
  		<ul class="navbar-nav">
    		<li class="nav-item">
     			<p id="name">Admin Dashboard</p>
    		</li>
    		<li class="nav-item">
    		  <a class="nav-link btn nav-button text-light" href="insert.php"><b>INSERT</b></a>
    		</li>
    		<li class="nav-item">
    		  <a class="nav-link btn nav-button text-light" id="btn" href="product.php"><b>PRODUCT</b></a>
    		</li>
    		<li class="nav-item">
    		  <a class="nav-link btn nav-button text-light" href="orders.php"><b>ORDERS</b></a>
    		</li>
			<li class="nav-item">
    		  <a class="nav-link btn nav-button text-light" href="membership.php"><b>MEMBERS</b></a>
    		</li>
    		<li class="nav-item">
    		  <a class="nav-link btn nav-button text-light" href="feedback.php"><b>FEEDBACK</b></a>
    		</li>
    		<li class="nav-item">
    		  <a class="nav-link btn nav-button text-light" href="logout.php"><b>LOG OUT</b></a>
    		</li>
  		</ul> 
	</nav>

    <main>
		<section>
			<div class="jumbotron" id="bg-black">
          	  <h1 class="bounce-top text-center" id="class-heading">Products</h1>
       		</div>
		</section>
		<section>
			<div class="container">
				<h1 class="feature-heading">Categories</h1>
				<br><br>
				<div class="row">
					<div class="card-group">
						<div class="card" style="width: 18rem;">
  							<img src="img/dumbbells/dumbbells.jpg" class="card-img-top" alt="Dumbbells">
  							<div class="card-body" align="center">
    							<a href="dumbbells.php" class="btn text-light" id="btn">Dumbbells</a>
 							</div>
						</div>
						&nbsp;
						<div class="card" style="width: 18rem;">
  							<img src="img/barbells/barbell.jpg" class="card-img-top" alt="barbells">
  							<div class="card-body" align="center">
    							<a href="barbell.php" class="btn text-light" id="btn">Barbells and Weights</a>
 							</div>
						</div>
						&nbsp;
						<div class="card" style="width: 18rem;">
  							<img src="img/supplements/supplements.jpg" class="card-img-top" alt="supplements">
  							<div class="card-body" align="center">
    							<a href="supplements.php" class="btn text-light" id="btn">Supplements</a>
 							</div>
						</div>
						&nbsp;
						<div class="card" style="width: 18rem;">
  							<img src="img/machines/machines.jpg" class="card-img-top" alt="Machines">
  							<div class="card-body" align="center">
    							<a href="machines.php" class="btn text-light" id="btn">Machines</a>
 							</div>
						</div>
					</div><!--/card-group-->
				</div><!--/row-->
				
			</div><!--/container-->
		</section>
    </main><br><br>

    <footer>
		<br>
		<div class="container text-center">
			<div class="text-light">
				Copyright &copy; Alpha Fitness.Co
			</div>
		</div>
		<br>
	</footer>

</body>
</html>