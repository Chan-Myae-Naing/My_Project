<?php

    error_reporting(1);
    $i = $_REQUEST["img"];
    include("connection.php");
    $i = $_REQUEST["img"];
    if($_POST["ord"]){
        $prod_name = $_POST["prod_name"];
        $price = $_POST["price"];
        $name = $_POST["name"];
        $ph = $_POST["ph"];
        $addr = $_POST["addr"];
        $ord_no = rand(1000,9999);
        if(mysql_query("insert into orders(prod_name, price, name, phone, addr, ord_no) values('$prod_name', '$price', '$name', '$ph', '$addr', '$ord_no')")){
            $Ty = "<h1 class='text-success' style='font-weight:bold; text-shadow:0px 0px 10px'>Your order has sent successfully. Thank you!</h1>";
            $ord = "<div class='row'>
            <div class='col bounce-in-left'><h5>Your order code</h5></div>
            <div class='col bounce-in-right'><input value='$ord_no &nbsp; (Remember this code)' type='text' size='30' readonly></div>
            </div><br>";
        }
        else{
            die(mysql_error());
        }
    }

?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="code/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="style.css">
	<link rel="stylesheet" type="text/css" href="animation.css">
	<script type="text/javascript" src="code/bootstrap.min.js"></script>
	<script type="text/javascript" src="code/jquery.min.js"></script>
	<script type="text/javascript" src="code/popper.min.js"></script>
	<title>Alpha Fitness</title>
</head>
<body data-spy="scroll" data-target=".navbar" data-offset="50">

	<nav class="navbar navbar-expand-sm navbar-dark fixed-top" id="navbar">
  		<ul class="navbar-nav">
    		<li class="nav-item">
     			<p id="name" href="index.html">Alpha Fitness</p>
    		</li>
    		<li class="nav-item">
    		  <a class="nav-link btn nav-button text-light" href="home.php"><b>HOME</b></a>
    		</li>
    		<li class="nav-item">
    		  <a class="nav-link btn nav-button text-light" href="classes.php"><b>CLASSES</b></a>
    		</li>
    		<li class="nav-item">
    		  <a class="nav-link btn nav-button text-light" href="trainers.php"><b>TRAINERS</b></a>
    		</li>
    		<li class="nav-item">
    		  <a class="nav-link btn nav-button text-light" href="schedules.php"><b>SCHEDULES</b></a>
    		</li>
    		<li class="nav-item">
    		  <a class="nav-link btn nav-button text-light" href="contact.php"><b>CONTACT US</b></a>
    		</li>
    		<li class="nav-item">
    		  <a class="nav-link btn nav-button text-light" href="marketplace.php"><b>MARKETPLACE</b></a>
    		</li>
  		</ul>
	</nav>

	<main>
        <?php
        
            include("connection.php");
            $sel = mysql_query("select * from machines where img='$i'");
            $mat = mysql_fetch_array($sel);
    
        ?>
        
        <div class="container classes text-center bounce-top" style="padding:3%;">
	    	<h1 class="class-heading">Order Form</h1>
	    </div>

		<div class="container text-light">
            <center><?php echo $Ty."<br>"; ?></center>
            <form method="post" style="margin-left:18%;">
                <?php echo $ord; ?>
                <div class="row">
                    <div class="col">
                        <h5>Product Name</h5>
                    </div>
                    <div class="col">
                        <input value="<?php echo $mat['prod_name']; ?>" type="text" size="30" name="prod_name" readonly required>
                    </div>
                </div>
                <br>
                <div class="row">
                    <div class="col">
                        <h5>Price</h5>
                    </div>
                    <div class="col">
                        <input value="<?php echo $mat['price']; ?>" type="text" size="30" name="price" readonly required>
                    </div>
                </div>
                <br>
                <div class="row">
                    <div class="col">
                        <h5>Your Name</h5>
                    </div>
                    <div class="col">
                        <input value="<?php echo $_POST['name'] ?>" type="text" size="30" name="name" required>
                    </div>
                </div>
                <br>
                <div class="row">
                    <div class="col">
                        <h5>Phone</h5>
                    </div>
                    <div class="col">
                        <input value="<?php echo $_POST['ph'] ?>" type="text" size="30" name="ph" required>
                    </div>
                </div>
                <br>
                <div class="row">
                    <div class="col">
                        <h5>Address</h5>
                    </div>
                    <div class="col">
                    <input value="<?php echo $_POST['addr'] ?>" type="text" size="30" name="addr" required>
                    </div>
                </div>
                <br>
                <div class="row">
                    <a href="machines.php" class="btn btn-secondary" style="margin-left:18%;">Go Back</a>
                    <input type="submit" value="Send Order" name="ord" class="btn btn-danger" id="btn" style="margin-left:18%;">
                </div>
            </form>
        </div>
	</main><br><br>

	<footer>
		<br>
		<div class="container text-center">
			<div class="text-light">
				Copyright &copy; Alpha Fitness.Co
			</div>
		</div>
		<br>
	</footer>

</body>
</html>