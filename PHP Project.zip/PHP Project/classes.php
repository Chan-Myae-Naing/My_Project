<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="code/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="style.css">
	<link rel="stylesheet" type="text/css" href="animation.css">
	<script type="text/javascript" src="code/bootstrap.min.js"></script>
	<script type="text/javascript" src="code/jquery.min.js"></script>
	<script type="text/javascript" src="code/popper.min.js"></script>
	<title>Alpha Fitness</title>
</head>
<body data-spy="scroll" data-target=".navbar" data-offset="50">
	
	<nav class="navbar navbar-expand-sm navbar-dark fixed-top" id="navbar">
  		<ul class="navbar-nav">
    		<li class="nav-item">
     			<p id="name" href="index.html">Alpha Fitness</p>
    		</li>
    		<li class="nav-item">
    		  <a class="nav-link btn nav-button text-light" href="home.php"><b>HOME</b></a>
    		</li>
    		<li class="nav-item">
    		  <a class="nav-link btn nav-button text-light" id="btn" href="classes.php"><b>CLASSES</b></a>
    		</li>
    		<li class="nav-item">
    		  <a class="nav-link btn nav-button text-light" href="trainers.php"><b>TRAINERS</b></a>
    		</li>
    		<li class="nav-item">
    		  <a class="nav-link btn nav-button text-light" href="schedules.php"><b>SCHEDULES</b></a>
    		</li>
    		<li class="nav-item">
    		  <a class="nav-link btn nav-button text-light" href="contact.php"><b>CONTACT US</b></a>
    		</li>
    		<li class="nav-item">
    		  <a class="nav-link btn nav-button text-light" href="marketplace.php"><b>MARKETPLACE</b></a>
    		</li>
  		</ul>
	</nav>

	<main>
	<section>
	<div class="jumbotron text-center classes">
		<h1 class="class-heading bounce-top">Our Classes</h1>
	</div>
	<div class="container">
		<div class="row">
			<div class="card-group">
  				<div class="card classes class-border text-light">
    				<img src="img/boxing-class.jpg" class="card-img-top" alt="Boxing class">
    				<div class="card-body">
      					<h3 class="card-title heading">Boxing</h3>
      					<p class="card-text">Trainer - <b>Mike Tyson</b></p>
      					<div class="row">
      						<div class="col">
      							<h5>Daily</h5>
      						</div>
      						<div class="col">
      							<h5>A Month</h5>
      						</div>
      					</div>
      					<div class="row text-muted">
      						<div class="col">
      							6,000 mmk
      						</div>
      						<div class="col">
      							40,000 mmk
      						</div>
      					</div>
    				</div>
  				</div>
  				<div class="card classes class-border text-light">
    				<img src="img/yoga-class.jpg" class="card-img-top" alt="Yoga class">
    				<div class="card-body">
      					<h3 class="card-title heading">Yoga</h3>
      					<p class="card-text">Trainer - <b>Anna</b></p>
      					<div class="row">
      						<div class="col">
      							<h5>Daily</h5>
      						</div>
      						<div class="col">
      							<h5>A Month</h5>
      						</div>
      					</div>
      					<div class="row text-muted">
      						<div class="col">
      							3,000 mmk
      						</div>
      						<div class="col">
      							30,000 mmk
      						</div>
      					</div>
    				</div>
  				</div>
  				<div class="card classes class-border text-light">
    				<img src="img/aerobic-class.png" class="card-img-top" alt="Aerobic class">
    				<div class="card-body">
      					<h3 class="card-title heading">Aerobic</h3>
      					<p class="card-text">Trainer - <b>Bella</b></p>
      					<div class="row">
      						<div class="col">
      							<h5>Daily</h5>
      						</div>
      						<div class="col">
      							<h5>A Month</h5>
      						</div>
      					</div>
      					<div class="row text-muted">
      						<div class="col">
      							4,000 mmk
      						</div>
      						<div class="col">
      							40,000 mmk
      						</div>
      					</div>
    				</div>
  				</div>
			</div>
		</div><!--row1-->
		<br>
		<div class="row">
			<div class="card-group">
  				<div class="card classes class-border text-light">
    				<img src="img/bodybuilding-class.jpg" class="card-img-top" alt="Body-Building class">
    				<div class="card-body">
      					<h3 class="card-title heading">Body-Building</h3>
      					<p class="card-text">Trainer - <b>Chris Bumstead</b></p>
      					<div class="row">
      						<div class="col">
      							<h5>Daily</h5>
      						</div>
      						<div class="col">
      							<h5>A Month</h5>
      						</div>
      					</div>
      					<div class="row text-muted">
      						<div class="col">
      							1,000 mmk
      						</div>
      						<div class="col">
      							30,000 mmk
      						</div>
      					</div>
    				</div>
  				</div>
  				<div class="card classes class-border text-light">
    				<img src="img/weightlifting-class.jpg" class="card-img-top" alt="Weight-lifting class">
    				<div class="card-body">
      					<h3 class="card-title heading">Weight-lifting</h3>
      					<p class="card-text">Trainer - <b>Eddie Hall</b></p>
      					<div class="row">
      						<div class="col">
      							<h5>Daily</h5>
      						</div>
      						<div class="col">
      							<h5>A Month</h5>
      						</div>
      					</div>
      					<div class="row text-muted">
      						<div class="col">
      							3,000 mmk
      						</div>
      						<div class="col">
      							30,000 mmk
      						</div>
      					</div>
    				</div>
  				</div>
  				<div class="card classes class-border text-light">
    				<img src="img/karate-class.jpg" class="card-img-top" alt="Karate class">
    				<div class="card-body">
      					<h3 class="card-title heading">Karate for Kids</h3>
      					<p class="card-text">Trainer - <b>John Doe</b></p>
      					<div class="row">
      						<div class="col">
      							<h5>Daily</h5>
      						</div>
      						<div class="col">
      							<h5>A Month</h5>
      						</div>
      					</div>
      					<div class="row text-muted">
      						<div class="col">
      							5,000 mmk
      						</div>
      						<div class="col">
      							35,000 mmk
      						</div>
      					</div>
    				</div>
  				</div>
			</div>
		</div><!--row2-->
	</div><!--/container-->
	<br><br>
	</section>
	</main>

	<footer>
		<br>
		<div class="container text-center">
			<div class="text-light">
				Copyright &copy; Alpha Fitness.Co
			</div>
		</div>
		<br>
	</footer>