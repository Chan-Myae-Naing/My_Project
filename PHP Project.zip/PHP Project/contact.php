<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="code/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="style.css">
	<link rel="stylesheet" type="text/css" href="animation.css">
	<script type="text/javascript" src="code/bootstrap.min.js"></script>
	<script type="text/javascript" src="code/jquery.min.js"></script>
	<script type="text/javascript" src="code/popper.min.js"></script>
	<title>Alpha Fitness</title>
</head>
<body data-spy="scroll" data-target=".navbar" data-offset="50">
	
	<nav class="navbar navbar-expand-sm navbar-dark fixed-top" id="navbar">
  		<ul class="navbar-nav">
    		<li class="nav-item">
     			<p id="name" href="index.html">Alpha Fitness</p>
    		</li>
    		<li class="nav-item">
    		  <a class="nav-link btn nav-button text-light" href="home.php"><b>HOME</b></a>
    		</li>
    		<li class="nav-item">
    		  <a class="nav-link btn nav-button text-light" href="classes.php"><b>CLASSES</b></a>
    		</li>
    		<li class="nav-item">
    		  <a class="nav-link btn nav-button text-light" href="trainers.php"><b>TRAINERS</b></a>
    		</li>
    		<li class="nav-item">
    		  <a class="nav-link btn nav-button text-light" href="schedules.php"><b>SCHEDULES</b></a>
    		</li>
    		<li class="nav-item">
    		  <a class="nav-link btn nav-button text-light" id="btn" href="contact.php"><b>CONTACT US</b></a>
    		</li>
    		<li class="nav-item">
    		  <a class="nav-link btn nav-button text-light" href="marketplace.php"><b>MARKETPLACE</b></a>
    		</li>
  		</ul> 
	</nav>

	<main>
	<section>
	<div class="jumbotron text-center classes">
		<h1 class="class-heading bounce-top">Contact</h1>
	</div>

	<div class="container">
		<div class="row">
			<div class="col slide-out-bottom">
				<h2 class="text-light feature-heading">Feel free to ask anything</h2><br>
				<form method="post">
					<input type="text" placeholder="Name" required name="name" size="28"><br><br>
					<input type="email" placeholder="Email" required name="email" size="28"><br><br>
					<textarea cols="30" placeholder="Message" required name="msg"></textarea><br><br>

					<?php

					error_reporting(1);
					include("connection.php");
					if($_POST["sub"]){
						$name = $_POST["name"];
						$email = $_POST["email"];
						$msg = $_POST["msg"];
						if(mysql_query("insert into contact(Name,Email,Message) values('$name','$email','$msg')")){
							echo "<p class='text-success' style='font-weight:bold;'>Message sent successfully!</p>";
						}
						else{
							die("<p class='text-light'>Unexpected error occured! Try not using ' ' in your message.</p>"."<a href='contact.php'>Go Back</a>");
						}
					}

					?>

					<input type="reset" value="Cancel" class="btn btn-secondary">
					<input style="margin-left:60px;" type="submit" value="Submit" name="sub" class="btn text-light" id="btn">
				</form>	
			</div>
			<div class="col slide-in-right-1">
				<h2 class="text-light feature-heading">Where you can find us</h2>
				<div class="row text-secondary">
					<div class="col">Telephone : </div>
					<div class="col">09 772588257</div>
				</div>
				<br>
				<div class="row text-secondary">
					<div class="col">Address : </div>
					<div class="col">Damaryone St., Tharkayta, Yangon</div>
				</div><br>
				<div class="google-map">
                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d5722.736863212245!2d96.21354875233635!3d16.803093896544706!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x30c1ed38ed6d34b1%3A0x71b6be84c0ccb461!2z4YCT4YCZ4YC54YCZ4YCs4YCb4YCv4YC24YCc4YCZ4YC64YC4LCDhgJvhgJThgLrhgIDhgK_hgJThgLo!5e0!3m2!1smy!2smm!4v1670615385749!5m2!1smy!2smm" width="500" height="200" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                </div>
			</div>
		</div><!--row-->
	</div><!--container-->
	<br><br>
	</section>
	</main>

	<footer>
		<br>
		<div class="container text-center">
			<div class="text-light">
				Copyright &copy; Alpha Fitness.Co
			</div>
		</div>
		<br>
	</footer>