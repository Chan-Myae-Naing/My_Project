

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="code/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="style.css">
	<link rel="stylesheet" type="text/css" href="animation.css">
	<script type="text/javascript" src="code/bootstrap.min.js"></script>
	<script type="text/javascript" src="code/jquery.min.js"></script>
	<script type="text/javascript" src="code/popper.min.js"></script>
	<title>Alpha Fitness</title>
</head>

<body data-spy="scroll" data-target=".navbar" data-offset="50">
	<main>
		<div class="container">
			<center>
			<div class="card" style="width: 18rem; margin: 13%;">
				<form method="post">
					<h1 class="card-header" id="login-header">Login</h1><br>
					<input type="email" name="email" placeholder="Email" size="30" required><br><br>
					<input type="password" name="pass" placeholder="Password" size="30" required>

					<?php

					session_start();
					error_reporting(1);
					include("connection.php");
					if($_POST["sub"]){
						$d = mysql_query("select * from register where Email='{$_POST['email']}' ");
						$row = mysql_fetch_object($d);
						$femail = $row->Email;
						$fpass = $row->Password;
						if($femail == $_POST["email"] && $fpass == $_POST["pass"]){
							$_SESSION["sid"] = $_POST["email"];
							header("location:home.php");
						}
						else{
							echo "<br><br><p style='color:red; font-weight:bold;'>Invalid email or password!</p>";
						}
					}

					?>

					<p class="text-muted">New User?<a href="register.php">Sign Up</a></p>
					<div class="card-footer text-center">
						<div class="row">
							<div class="col">
								<input type="reset" value="Cancel" class="btn btn-secondary">
							</div>
							<div class="col">
								<input type="submit" value="Submit" name="sub" class="btn btn-danger" id="btn">
							</div>
						</div>
					</div>
				</form>
			</div>
			</center>
		</div>
	</main>


</body>
</html>