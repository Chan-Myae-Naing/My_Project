

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="code/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="style.css">
	<link rel="stylesheet" type="text/css" href="animation.css">
	<script type="text/javascript" src="code/bootstrap.min.js"></script>
	<script type="text/javascript" src="code/jquery.min.js"></script>
	<script type="text/javascript" src="code/popper.min.js"></script>
	<title>Alpha Fitness</title>
</head>
<body data-spy="scroll" data-target=".navbar" data-offset="50">
	
	<nav class="navbar navbar-expand-sm navbar-dark fixed-top" id="navbar">
  		<ul class="navbar-nav">
    		<li class="nav-item">
     			<p id="name" href="index.html">Alpha Fitness</p>
    		</li>
    		<li class="nav-item">
    		  <a class="nav-link btn nav-button text-light" id="btn" href="home.php"><b>HOME</b></a>
    		</li>
    		<li class="nav-item">
    		  <a class="nav-link btn nav-button text-light" href="classes.php"><b>CLASSES</b></a>
    		</li>
    		<li class="nav-item">
    		  <a class="nav-link btn nav-button text-light" href="trainers.php"><b>TRAINERS</b></a>
    		</li>
    		<li class="nav-item">
    		  <a class="nav-link btn nav-button text-light" href="schedules.php"><b>SCHEDULES</b></a>
    		</li>
    		<li class="nav-item">
    		  <a class="nav-link btn nav-button text-light" href="contact.php"><b>CONTACT US</b></a>
    		</li>
    		<li class="nav-item">
    		  <a class="nav-link btn nav-button text-light" href="marketplace.php"><b>MARKETPLACE</b></a>
    		</li>
  		</ul> 
	</nav>

	<main>
	<section>
	<div class="text-center" id="home">
		<h3 class="slogan text-flicker-in-glow">Make yourself stronger than your excuses!</h3><br>
		<h1 id="greeting" class="text-flicker-in-glow">Get a Perfect Body at <p class="heading">Alpha Fitness</p></h1><br><br><br>
		<a class="btn btn-danger text-light bounce-top" id="btn" href="#feature">Get Started</a>
	</div><br>
	</section>

	<section>
	<div class="container" id="feature">
  		<div class="row">
    		<div class="col-sm-4">
    			<h1 class="feature-heading">New To Alpha?</h1>
      			<p class="text-light">Your Gym Membership is 30,000 mmk a month</p>
      			<a href="membership.php" class="btn btn-danger text-light" id="btn">Become a Member</a>
    		</div>
    		<div class="col-sm-4 text-center"><br><br></div>
    		<div class="col-sm-4">
      			<h1 class="feature-heading">Opening Hours</h1><br>
      			<h3 class="text-light">Monday - Saturday</h3>
      			<p class="text-success">6:00 AM - 8:00 PM</p>
      			<h3 class="text-light">Sunday</h3>
      			<p class="heading">Closed</p>
    		</div>
  		</div>
	</div><!--container-->
	</section>
	</main>

	<br><br>

	<footer>
		<br>
		<div class="container text-center">
			<div class="text-light">
				Copyright &copy; Alpha Fitness.Co
			</div>
		</div>
		<br>
	</footer>
</body>
</html>