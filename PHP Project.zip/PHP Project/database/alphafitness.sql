-- phpMyAdmin SQL Dump
-- version 3.4.10.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 26, 2023 at 01:30 PM
-- Server version: 5.5.20
-- PHP Version: 5.3.10

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `alphafitness`
--

-- --------------------------------------------------------

--
-- Table structure for table `barbells`
--

CREATE TABLE IF NOT EXISTS `barbells` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `img` varchar(20) NOT NULL,
  `prod_name` varchar(30) NOT NULL,
  `prod_info` varchar(50) NOT NULL,
  `price` int(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `barbells`
--

INSERT INTO `barbells` (`id`, `img`, `prod_name`, `prod_info`, `price`) VALUES
(1, 'straight.jpg', 'Straight Bar', 'Barbell Weight Bar,5ft.,700lbs Capacity', 20000),
(2, 'ez.jpg', 'EZ Bar', 'EZ Curl Bar - Balck, Size:47"', 20000),
(3, 'multi-grip.jpg', 'Multi Grip Bar', 'Multi-Grip Angled Swiss Bar', 25000),
(4, '10lbs.jpg', '10lbs Plate', 'Low-Bounce Bumper Plate', 9000),
(5, '25lbs.jpg', '25lbs Plate', 'Low-Bounce Bumper Plate', 22500),
(6, '45lbs.jpg', '45lbs Plate', 'Low-Bounce Bumper Plate', 40500),
(7, '55lbs.jpg', '55lbs Plate', 'Low-Bounce Bumper Plate', 49500);

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE IF NOT EXISTS `contact` (
  `con id` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(30) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Message` varchar(100) NOT NULL,
  PRIMARY KEY (`con id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`con id`, `Name`, `Email`, `Message`) VALUES
(1, 'Chan Myae Naing', 'chanmyaenaing0101@gmail.com', 'Hello there~'),
(2, 'Herry', 'herry@gmail.com', 'Hi~'),
(3, 'Anubis', 'anubis@gmail.com', 'Hello, I am Anubis'),
(4, 'Lucifer', 'lucifer@gmail.com', 'Hellllooo there, I am the great Lucifer Morningstar'),
(5, 'Random Anime girl', 'rag@gmail.com', 'ara ara~'),
(6, 'Terminator ', 'T8000@gmail.com', 'Hasta la vista, baby!'),
(7, 'Dr. Stephen Strange', 'drstrange@gmail.com', 'I love you in every universe.'),
(8, 'Captain America', 'cap@gmail.com', 'I can do this all day!'),
(9, 'Winnie the Pooh', 'pooh@gmail.com', 'How lucky I am to have something that makes saying goodbye so hard.'),
(10, 'Batman', 'iambatman@gmail.com', 'Losing people is a part of life, but that does not mean you stop letting them in.'),
(11, 'Jake', 'jakethedog@gmail.com', 'Sucking at something is the first step at being sorta good at something.'),
(12, 'Unknown', 'unknown@gmail.com', 'You are not doing it wrong if people do not know what you are doing.\r\n'),
(13, 'Princess Bubblegum', 'bubblegum@gmail.com', 'People get built different. We do not have to figure it out. We just have to respect it.'),
(14, 'Captain Jack Sparrow', 'jack@gmail.com', 'The problem is not the problem. The problem is your attitude about the problem.'),
(15, 'Rocky', 'rocky@gmail.com', 'It is not about how hard you can hit, it is about how hard you can get hit and keep moving forward. '),
(16, 'Joker', 'joker@gmail.com', 'If you are good at something, never do it for free.');

-- --------------------------------------------------------

--
-- Table structure for table `dumbbells`
--

CREATE TABLE IF NOT EXISTS `dumbbells` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `img` varchar(20) NOT NULL,
  `prod_name` varchar(30) NOT NULL,
  `prod_info` varchar(50) NOT NULL,
  `price` int(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `dumbbells`
--

INSERT INTO `dumbbells` (`id`, `img`, `prod_name`, `prod_info`, `price`) VALUES
(1, '3kg.jpg', '3kg Dumbbells', '3kg Rubber Hex Dumbbell pair', 27000),
(2, '4kg.jpg', '4kg Dumbbells', '4kg Rubber Hex Dumbbell pair', 36000),
(3, '5kg.jpg', '5kg Dumbbells', '5kg Rubber Hex Dumbbell pair', 45000),
(4, '6kg.jpg', '6kg Dumbbells', '6kg Rubber Hex Dumbbell pair', 54000),
(5, '7.5kg.jpg', '7.5kg Dumbbells', '7.5kg Rubber Hex Dumbbell pair', 67500),
(6, '8kg.jpg', '8kg Dumbbells', '8kg Rubber Hex Dumbbell pair', 72000),
(7, '10kg.jpg', '10kg Dumbbells', '10kg Rubber Hex Dumbbell pair', 90000),
(8, '12.5kg.jpg', '12.5kg Dumbbells', '12.5kg Rubber Hex Dumbbell pair', 112500),
(9, '15kg.jpg', '15kg Dumbbells', '15kg Rubber Hex Dumbbell pair', 135000),
(10, '17.5kg.jpg', '17.5kg Dumbbells', '17.5kg Rubber Hex Dumbbell pair', 157500),
(11, '20kg.jpg', '20kg Dumbbells', '20kg Rubber Dumbbell pair', 180000),
(12, '25kg.jpg', '25kg Dumbbells', '25kg Rubber Hex Dumbbell pair', 225000);

-- --------------------------------------------------------

--
-- Table structure for table `machines`
--

CREATE TABLE IF NOT EXISTS `machines` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `img` varchar(20) NOT NULL,
  `prod_name` varchar(30) NOT NULL,
  `prod_info` varchar(50) NOT NULL,
  `price` int(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `machines`
--

INSERT INTO `machines` (`id`, `img`, `prod_name`, `prod_info`, `price`) VALUES
(1, 'smith.jpg', 'Smith Machine', 'Smith Machine with Weights', 1680000),
(2, 'cable.jpg', 'Cable Machine', 'Cable Machine with dual 200lbs weight stacks', 1806000),
(3, 'leg-press.jpg', 'Leg Press Machine', 'Leg Press Machine with Weights', 1785000);

-- --------------------------------------------------------

--
-- Table structure for table `membership`
--

CREATE TABLE IF NOT EXISTS `membership` (
  `memID` int(11) NOT NULL AUTO_INCREMENT,
  `FirstName` varchar(20) NOT NULL,
  `LastName` varchar(20) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Mobile` varchar(20) NOT NULL,
  `Address` varchar(100) NOT NULL,
  `BirthMonth` varchar(10) NOT NULL,
  `BirthDay` int(10) NOT NULL,
  `BirthYear` int(10) NOT NULL,
  `Package` varchar(30) NOT NULL,
  `Payment` varchar(10) NOT NULL,
  `Knownfrom` varchar(10) NOT NULL,
  PRIMARY KEY (`memID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=36 ;

--
-- Dumping data for table `membership`
--

INSERT INTO `membership` (`memID`, `FirstName`, `LastName`, `Email`, `Mobile`, `Address`, `BirthMonth`, `BirthDay`, `BirthYear`, `Package`, `Payment`, `Knownfrom`) VALUES
(28, 'Chan Myae', 'Naing', 'cmn@gmail.com', '09546637465', 'Tharkayta Township', 'August', 17, 2000, '3 months - ks 80,000', 'Cash', 'Google'),
(29, 'Harry', '', 'harry@gmail.com', '09554657648', 'East Dagon, Yangon', 'March', 4, 2004, '1 months - ks 30,000', 'Wavepay', 'Facebook'),
(30, 'Bruce', 'Wayne', 'iambatman@gmail.com', '09664563546', 'Gotham City, Wayne Manor.', 'November', 26, 1980, '1 year - ks 320,000', 'Kpay', 'From a fri'),
(31, 'Hercules', '', 'hercules@gmail.com', '09776768898', 'On Earth', 'October', 30, 2003, '6 months - ks 160,000', 'Cash', 'Other'),
(32, 'Mufasa', '', 'mufasa@gmail.com', '09775645546', 'Somewhere in the jungle', 'September', 13, 2007, '1 months - ks 30,000', 'Kpay', 'Facebook'),
(33, 'Shrek', '', 'shrek@gmail.com', '09664536448', 'Some random swamp', 'April', 4, 1990, '1 months - ks 30,000', 'Kpay', 'Google'),
(34, 'Olaf', '', 'olaf@gmail.com', '09887465789', 'Kingdom of Arendelle', 'March', 18, 2005, '9 months - ks 240,000', 'Cash', 'Facebook'),
(35, 'Elsa', '', 'elsa@gmail.com', '09554563578', 'Kingdom of Arendelle', 'December', 16, 1987, '1 year - ks 320,000', 'Wavepay', 'Facebook');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE IF NOT EXISTS `orders` (
  `ord_id` int(11) NOT NULL AUTO_INCREMENT,
  `prod_name` varchar(30) NOT NULL,
  `price` int(20) NOT NULL,
  `name` varchar(40) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `addr` varchar(100) NOT NULL,
  `ord_no` int(10) NOT NULL,
  PRIMARY KEY (`ord_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`ord_id`, `prod_name`, `price`, `name`, `phone`, `addr`, `ord_no`) VALUES
(5, 'Whey Protein', 240000, 'Eren Yeager', '09767654535', 'Merlay', 2127),
(6, 'Leg Press Machine', 1785000, 'Lucifer', '09645233432', 'somewhere in hell', 5644),
(7, 'Smith Machine', 1680000, 'Zues', '09645534546', 'Mount Olympia', 2419),
(8, '25kg Dumbbells', 225000, 'Hercules', '09778766678', 'On Earth', 2844),
(9, '20kg Dumbbells', 180000, 'Thanos', '09775344234', 'Somewhere in the universe', 3515),
(10, '8kg Dumbbells', 72000, 'Steve', '09665774689', 'S.H.I.E.L.D Helicarrier', 1432),
(11, 'EZ Bar', 20000, 'Chris Bumstead', '09887344256', 'Canada', 4433),
(12, '55lbs Plate', 49500, 'Arnold Schwarzenegger', '09223453456', 'Australia', 2299),
(13, 'Multi Grip Bar', 25000, 'Zenitsu', '09554637789', 'Somewhere in the jungle', 8952),
(14, '25lbs Plate', 22500, 'Annie', '09667655478', 'Paradis island', 3632),
(15, 'Whey Protein', 240000, 'Chan Myae Naing', '09775647568', 'Yangon', 7592),
(16, 'Leg Press Machine', 1785000, 'Bane', '09885768576', 'Gotham City', 1439),
(17, '3kg Dumbbells', 27000, 'Nezuko', '09776755456', 'wherever Tanjiro is', 5801),
(18, '5kg Dumbbells', 45000, 'Sasha', '09564776735', 'Training Camp', 3120);

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE IF NOT EXISTS `register` (
  `reg id` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(40) NOT NULL,
  `Email` varchar(40) NOT NULL,
  `Password` varchar(20) NOT NULL,
  `Phone` varchar(30) NOT NULL,
  `City` varchar(30) NOT NULL,
  `Address` varchar(100) NOT NULL,
  PRIMARY KEY (`reg id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=25 ;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`reg id`, `Name`, `Email`, `Password`, `Phone`, `City`, `Address`) VALUES
(21, 'Chan Myae Naing', 'chanmyaenaing0101@gmail.com', '12345', '09772588257', 'Yangon', 'Tharkayta Township'),
(23, 'Ryan', 'ryan@gmail.com', '1234', '09787878787', 'Mandalay', 'Somewhere in Mandalay.'),
(24, 'Herry', 'herry@gmail.com', '1234', '0988888888', 'Taunggyi', 'Somewhere in Taunggyi.');

-- --------------------------------------------------------

--
-- Table structure for table `supplements`
--

CREATE TABLE IF NOT EXISTS `supplements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `img` varchar(20) NOT NULL,
  `prod_name` varchar(30) NOT NULL,
  `prod_info` varchar(50) NOT NULL,
  `price` int(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `supplements`
--

INSERT INTO `supplements` (`id`, `img`, `prod_name`, `prod_info`, `price`) VALUES
(1, 'whey-gold.jpg', 'Whey Protein', 'Gold Standard Whey Protein', 240000);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `name` varchar(50) NOT NULL,
  `password` int(20) NOT NULL,
  KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`name`, `password`) VALUES
('admin', 12345);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
